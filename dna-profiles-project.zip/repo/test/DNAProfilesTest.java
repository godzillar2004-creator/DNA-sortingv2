package test; 

import static org.junit.Assert.*;
import org.junit.*; 

import dna.*;

/*
* This is a Java Test Class, which uses the JUnit package to create
* and run tests. You do NOT have to submit this class.
* 
* You can fill in these tests in order to evaluate your code. Writing tests
* is a crucial skill to have as a developer.
*/
public class DNAProfilesTest {

    @Test 
    public void testCreateSingleProfile(){

       // if you wish to test this method individually before testing assembleTree
        
        //REMOVE THIS STATEMENT WHEN YOU'VE IMPLEMENTED THE TEST
        fail("This test needs to be implemented before you can run it!");
    }

    @Test 
    public void testInsertPerson(){

       // if you wish to test this method individually before testing assembleTree
        
        //REMOVE THIS STATEMENT WHEN YOU'VE IMPLEMENTED THE TEST
        fail("This test needs to be implemented before you can run it!");
    }

    @Test 
    public void testAssembleTree(){

        DNAProfiles dnaProfiles = new DNAProfiles();
        // call the assembleTree method on this isntance with an input file
        
        //REMOVE THIS STATEMENT WHEN YOU'VE IMPLEMENTED THE TEST
        fail("This test needs to be implemented before you can run it!");
    }

    @Test
    public void testSearchByName(){

        //REMOVE THIS STATEMENT WHEN YOU'VE IMPLEMENTED THE TEST
        fail("This test needs to be implemented before you can run it!");
    }

    @Test   
    public void testMarkProfilesOfInterest(){

        

        //REMOVE THIS STATEMENT WHEN YOU'VE IMPLEMENTED THE TEST
        fail("This test needs to be implemented before you can run it!");
    }

    @Test
    public void testGetMatchingProfileCount(){
       
        //REMOVE THIS STATEMENT WHEN YOU'VE IMPLEMENTED THE TEST
        fail("This test needs to be implemented before you can run it!");
    }

    @Test
    public void testFindUnmarkedPeople(){
       

        //REMOVE THIS STATEMENT WHEN YOU'VE IMPLEMENTED THE TEST
        fail("This test needs to be implemented before you can run it!");
    }

    @Test
    public void testRemovePerson(){
        

        //REMOVE THIS STATEMENT WHEN YOU'VE IMPLEMENTED THE TEST
        fail("This test needs to be implemented before you can run it!");
    }

    @Test
    public void testCleanupTree(){


        //REMOVE THIS STATEMENT WHEN YOU'VE IMPLEMENTED THE TEST
        fail("This test needs to be implemented before you can run it!");
    }
}
