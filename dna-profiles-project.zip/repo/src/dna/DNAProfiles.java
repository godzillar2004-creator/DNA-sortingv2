package dna;

import edu.rutgers.cs112.BST.BSTNode;

/**
 * This class represents a DNA analysis system that manages the DNA data using
 * BSTs.
 * Contains methods to create, read, update, delete, search, and flag profiles.
 * 
 * @author Kal Pandit
 */
public class DNAProfiles {

    private BSTNode<Profile> rootNode;  // BST's root
    private String unknownSequence1;
    private String unknownSequence2;

    public DNAProfiles () {
        rootNode = null;
        unknownSequence1 = null;
        unknownSequence2 = null;
    }

    /**
     * Builds a simplified database as a BST and populates unknown sequences.
     * See the assignment description on the website for the full input file format.
     * 
     * DO NOT EDIT this method, IMPLEMENT createSingleProfile and insertPerson.
     * 
     * @param filename the name of the file to read from
     */
    public void assembleTree(String filename) {
        // DO NOT EDIT THIS CODE
        StdIn.setFile(filename); // DO NOT remove this line

        // Reads unknown sequences
        String sequence1 = StdIn.readLine();
        unknownSequence1 = sequence1;
        String sequence2 = StdIn.readLine();
        unknownSequence2 = sequence2;
        
        int numberOfPeople = Integer.parseInt(StdIn.readLine()); 

        for (int i = 0; i < numberOfPeople; i++) {
            // Reads name, count of STRs
            String fname = StdIn.readString();
            String lname = StdIn.readString();
            String fullName = lname + ", " + fname;
            // Calls buildSingleProfile to create
            Profile profileToAdd = createSingleProfile(fullName);
            // Calls insertPerson on that profile: inserts a key-value pair (name, profile)
            insertPerson(profileToAdd);
        }
    }

    /** 
     * Reads ONE profile from the input file and returns a new Profile object.
     * Do NOT add a StdIn.setFile statement, that is done for you in assembleTree.
     * 
     * See the assignment description on the website for the parts of the input file 
     * that you need to read. DONT read the name, that was already read in assembleTree
     *
     * @param fullName
     * @return
     */
    public Profile createSingleProfile(String fullName) {

         int s = StdIn.readInt();

    
    STR[] strs = new STR[s];

    
    for (int i = 0; i < s; i++) {
        String strName = StdIn.readString();
        int occurrences = StdIn.readInt();

        strs[i] = new STR(strName, occurrences);
    }

    
    return new Profile(fullName, strs);
       
       
    }

    /**
     * Inserts a node with a new Profile into
     * the binary search tree rooted at rootNode.
     * 
     * Names are the keys we use for the Profile objects.
     * USE the compareTo method.
     * 
     * @param newProfile the profile to be inserted
     */
    public void insertPerson(Profile newProfile) {

        BSTNode<Profile> newNode = new BSTNode<>(newProfile);

    
    if (rootNode == null) {
        rootNode = newNode;
        return;
    }

    BSTNode<Profile> current = rootNode;

    while (true) {
        String newName = newProfile.getFullName();
        String currentName = current.getData().getFullName();

        if (newName.compareTo(currentName) < 0) {
            
            if (current.getLeft() == null) {
                current.setLeft(newNode);
                return;
            }
            current = current.getLeft();
        } else {
            
            if (current.getRight() == null) {
                current.setRight(newNode);
                return;
            }
            current = current.getRight();
        }
    }

    }

    /**
     * Searches through the BST for a Profile associated with the given full name
     * This method MUST BE RECURSIVE,You will fill in code for the recursive helper
     * method below.   
     * 
     * @param fullName the full name of the Profile we are trying to find
     * @return the Profile object if it is found, or null if it is not found
     */
    public Profile searchByName(String fullName) {
        // DO NOT EDIT
        return searchByName(rootNode, fullName);
    }

    /**
     * Recursive helper method to help search for a Profile. This helper method MUST 
     * call itself at least once. 
     * 
     * @param currentNode the root of the current subtree being searched
     * @param fullName the full name of the Profile we are trying to find
     * @return the Profile object if it is found, or null if it is not found
     */
    private Profile searchByName(BSTNode<Profile> currentNode, String fullName) {
         
    if (currentNode == null) {
        return null;
    }

    String currentName = currentNode.getData().getFullName();

    int comparison = fullName.compareTo(currentName);

    
    if (comparison == 0) {
        return currentNode.getData();
    }
    
    else if (comparison < 0) {
        return searchByName(currentNode.getLeft(), fullName);
    }
    
    else {
        return searchByName(currentNode.getRight(), fullName);
    }
    }

    /**
     * Helper method that counts the # of STR occurrences in a sequence.
     * Provided method - DO NOT UPDATE.
     * 
     * @param sequence the sequence to search
     * @param STR      the STR to count occurrences of
     * @return the number of times STR appears in sequence
     */
    private int numberOfOccurrences(String sequence, String STR) {
        // DO NOT EDIT THIS CODE
        int repeats = 0;
        // STRs can't be greater than a sequence
        if (STR.length() > sequence.length())
            return 0;
        // indexOf returns the first index of STR in sequence, -1 if not found
        int lastOccurrence = sequence.indexOf(STR);
        while (lastOccurrence != -1) {
            repeats++;
            // Move start index beyond the last found occurrence
            lastOccurrence = sequence.indexOf(STR, lastOccurrence + STR.length());
        }
        return repeats;
    }

    /**
     * Traverses the BST at rootNode to mark profiles 
     * See the assignment description for the conditions to mark a profile 
     */
    public void markProfilesOfInterest() {
        markProfilesHelper(rootNode);
}

private void markProfilesHelper(BSTNode<Profile> node) {

    if (node == null) return;

    Profile profile = node.getData();
    STR[] strs = profile.getStrs();

    int matchCount = 0;
    int s = strs.length;

    for (int i = 0; i < s; i++) {
        String strName = strs[i].getStrString();
        int expected = strs[i].getOccurrences();

        int count1 = numberOfOccurrences(unknownSequence1, strName);
        int count2 = numberOfOccurrences(unknownSequence2, strName);

        int total = count1 + count2;

        if (total == expected) {
            matchCount++;
        }
    }

    int requiredMatches = (s + 1) / 2;

    if (matchCount >= requiredMatches) {
        profile.setInterestStatus(true);
    }

    // Traverse left and right
    markProfilesHelper(node.getLeft());
    markProfilesHelper(node.getRight());
    }

    /**
     * Finds the number of profiles in the BST whose interest status matches
     * the isOfInterest parameter.
     *
     * @param isOfInterest the search mode: whether we are searching for unmarked or
     *                     marked profiles. true if yes, false otherwise
     * @return the number of profiles according to the search mode marked
     */
    public int getMatchingProfileCount(boolean isOfInterest) {
         return countHelper(rootNode, isOfInterest);
}

private int countHelper(BSTNode<Profile> node, boolean isOfInterest) {

    if (node == null) {
        return 0;
    }

    int count = 0;

    Profile profile = node.getData();

    if (profile.getMarkedStatus() == isOfInterest) {
        count++;
    }

    // count left + right
    count += countHelper(node.getLeft(), isOfInterest);
    count += countHelper(node.getRight(), isOfInterest);

    return count;
    }

    /**
     * Uses a level-order traversal to populate an array of unmarked Strings representing unmarked people's names.
     * - USE the getMatchingProfileCount method to get the resulting array length.
     * - USE the provided Queue class to investigate a node and enqueue its
     * neighbors.
     * 
     * @return the array of unmarked people, in level order
     */
    public String[] findUnmarkedPeople() {

         int count = getMatchingProfileCount(false);
    String[] result = new String[count];

    if (rootNode == null) {
        return result;
    }

    Queue<BSTNode<Profile>> queue = new Queue<>();
    queue.enqueue(rootNode);

    int index = 0;

    while (!queue.isEmpty()) {
        BSTNode<Profile> current = queue.dequeue();
        Profile profile = current.getData();

        // Check if unmarked
        if (!profile.getMarkedStatus()) {
            result[index++] = profile.getFullName();
        }

        // Enqueue children
        if (current.getLeft() != null) {
            queue.enqueue(current.getLeft());
        }
        if (current.getRight() != null) {
            queue.enqueue(current.getRight());
        }
    }

    return result;
    }

    /**
     * Removes a SINGLE node from the BST rooted at rootNode, given a full name (Last, First)
     * This is similar to the BST delete we have seen in class.
     * 
     * If a profile containing fullName doesn't exist, do nothing.
     * You may assume that all names are distinct.
     * 
     * @param fullName the full name of the person to delete
     */
    public void removePerson(String fullName) {
         rootNode = removeHelper(rootNode, fullName);
}

private BSTNode<Profile> removeHelper(BSTNode<Profile> node, String fullName) {

    if (node == null) {
        return null;
    }

    String currentName = node.getData().getFullName();
    int comparison = fullName.compareTo(currentName);

    // Step 1: traverse
    if (comparison < 0) {
        node.setLeft(removeHelper(node.getLeft(), fullName));
    } 
    else if (comparison > 0) {
        node.setRight(removeHelper(node.getRight(), fullName));
    } 
    else {
        // FOUND NODE → delete it

        // Case 1: no children
        if (node.getLeft() == null && node.getRight() == null) {
            return null;
        }

        // Case 2: one child
        if (node.getLeft() == null) {
            return node.getRight();
        }
        if (node.getRight() == null) {
            return node.getLeft();
        }

        // Case 3: two children
        BSTNode<Profile> successor = findMin(node.getRight());
        Profile successorData = successor.getData();
        BSTNode<Profile> rightSubtree = removeHelper(node.getRight(), successorData.getFullName());
        BSTNode<Profile> replacement = new BSTNode<>(successorData);
        replacement.setLeft(node.getLeft());
        replacement.setRight(rightSubtree);
        return replacement;
    }

    return node;
    }

    /**
     * Finds the minimum node in the BST rooted at the given node.
     *
     * @param node the root of the subtree
     * @return the leftmost node in that subtree
     */
    private BSTNode<Profile> findMin(BSTNode<Profile> node) {
        if (node == null) {
            return null;
        }
        while (node.getLeft() != null) {
            node = node.getLeft();
        }
        return node;
    }

    /**
     * Clean up the tree by using previously written methods to remove unmarked
     * profiles.
     * Requires the use of findUnmarkedPeople and removePerson.
     */
    public void cleanupTree() {
         String[] unmarked = findUnmarkedPeople();

    for (int i = 0; i < unmarked.length; i++) {
        removePerson(unmarked[i]);
    }
    }

    /**
     * Gets the root of the binary search tree.
     *
     * @return The root of the binary search tree.
     */
    public BSTNode<Profile> getRootNode() {
        return rootNode;
    }

    /**
     * Sets the root of the binary search tree.
     *
     * @param newRoot The new root of the binary search tree.
     */
    public void setRootNode(BSTNode<Profile> newRoot) {
        rootNode = newRoot;
    }

    /**
     * Gets the first unknown sequence.
     * 
     * @return the first unknown sequence.
     */
    public String getFirstUnknownSequence() {
        return unknownSequence1;
    }

    /**
     * Sets the first unknown sequence.
     * 
     * @param newFirst the value to set.
     */
    public void setFirstUnknownSequence(String newFirst) {
        unknownSequence1 = newFirst;
    }

    /**
     * Gets the second unknown sequence.
     * 
     * @return the second unknown sequence.
     */
    public String getSecondUnknownSequence() {
        return unknownSequence2;
    }

    /**
     * Sets the second unknown sequence.
     * 
     * @param newSecond the value to set.
     */
    public void setSecondUnknownSequence(String newSecond) {
        unknownSequence2 = newSecond;
    }

}
